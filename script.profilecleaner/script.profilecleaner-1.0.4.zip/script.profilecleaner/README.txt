Installation
1. Download the zip
2. Install script.profilecleaner by zip. Go to Settings > Add-ons > Install from zip file > Choose the just downloaded zip
3. Navigate to Settings > Add-ons > Enabled add-ons > Program add-ons > Profile Cleaner
4. Select Profile Cleaner and go to Configure if you need to change the default configuration
5. Enjoy

Thanks
Special thanks to Max (m4x1m) Headroom for writing the original Thumbnails Cleaner upon which this addon is based.
