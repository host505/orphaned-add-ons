# coding: utf-8
# Created on: 06.04.2016
# Author: Roman Miroshnychenko aka Roman V.M. (romanvm@yandex.ua)


class Add7Exception(Exception):
    pass


class ParseError(Add7Exception):
    pass


class SubsSearchError(Add7Exception):
    pass


class ConnectionError(Add7Exception):
    pass


class DailyLimitError(Add7Exception):
    pass
